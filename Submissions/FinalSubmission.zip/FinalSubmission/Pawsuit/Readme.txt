# Read Me

---

## Contributors

---

1. Andrew Hong - s3785131
2. Louis - s3803253
3. Long Thanh Nguyen (Jack) - s3627601
4. Mishal Ahmed Shameer - s3852070
5. Tom Bennett - s3901953

---

## Controls

---

WASD      - move
Mouse     - adjust camera, navigate menus
SHIFT     - sprint
LMouse    - adjust lights

### Robber

Q - dash

R - Invisible

F - Night Vision

### Cop

Right Mouse click - ADS

Left Mouse click - Shoot

R - Sniff

F - Flashlight

---

## How to Play

---

2 Players Needed!

1. One player will create a lobby and might even give it a name.
2. Once created another player will list the lobbies and join
the respective lobby of their friend.
3. Both players will ready up, starting a countdown to load the
game scene!
4. Players will take it in turns playing both the Cop and the Robber.
5. The Robber aims to steal as many items as they can within the time
limit to stack up points.
6. The Cop aims to catch the robber reducing the rounds time limit and
providing them with a small amount of points.
7. The player with the most points at the end of the rounds WINS!!

---

## Known Bugs

---

1. The Respawn on getting caught is not immediate
2. Might have some issues connecting with the other player in the Lobby

## External Assets

---

MULTIPLAYER utilizes unity services (Relay, Lobby, Netcode for gameObjects)

SHADERS

---

1. Quibli Anime Shaders and Tools (Toon Shader and Skybox) https://assetstore.unity.com/packages/vfx/quibli-anime-shaders-and-tools-203178

---

SFX

---

1. Being Tasereded SFX- https://www.soundsnap.com/warfare_taser_gun_002_wav
2. Taser Firing SFX- https://www.soundsnap.com/electricity_taser_snapping_far_perspective_18
3. Night vision SFX- https://www.soundsnap.com/zoom_screen_switch_on_night_vision_binoculars_interface_tech_display_loaded_002628_wav
4. Dog Sniff SFX- https://www.soundsnap.com/animal_dog_big_sniffing_and_gasp_mono_96khz_wav
5. Dash SFX - https://www.pond5.com/sound-effects/item/192754128-movement_dodge_dash_whoosh_06
6. Footsteps - Unity Package Third Person Controller
7. BGM - Kenny Audio Pack https://kenney.itch.io/kenney-game-assets
8. UI buttons - Kenny Audio Pack https://kenney.itch.io/kenney-game-assets

---

1. Cursor - Kenny UI Pack https://kenney.itch.io/kenney-game-assets
2. Font - Nougat https://www.dafont.com/nougat.font